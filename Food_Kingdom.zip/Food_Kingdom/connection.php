	<?php
		$host = "host = localhost";
		$port = "port = 5433";
		$dbname = "dbname = Test";
		$user_info = "user = postgres password = '123'";